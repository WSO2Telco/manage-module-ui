const reportService = function () {

    return {

    };
};

module.exports = reportService();