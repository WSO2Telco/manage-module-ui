'use strict';

const commonServiceHelper = function () {
    return {
     //Common service goes here
    }
};

module.exports = commonServiceHelper();
