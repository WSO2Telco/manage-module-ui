/**
 * Created by sumudu on 1/26/17.
 */
module.exports = {
    APPROVAL_TYPES : {
        OPERATOR_ADMIN_APPROVAL : 'operatorAdminApproval',
        API_PUBLISHER_APPROVAL : 'apiPublisherApproval',
        HUB_ADMIN_APPROVAL : 'hubAdminApproval',
    }
};